from django.db import models
from tablamadre.models import TablaMadre

