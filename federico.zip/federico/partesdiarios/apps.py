from django.apps import AppConfig


class PartesdiariosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'partesdiarios'
